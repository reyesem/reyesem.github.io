#' Custom Word template.
#'
#' Loads additional style file for Word for MA382.
#'
#' @param ... additional arguments provided to \@code{word_document}.
#'
#' @export
ma382_word_format <- function(...) {
  # locations of resource files in the package
  pkg_resource <- function(...) {
    system.file(..., package = "reyes382")
  }

  wordstyle <- pkg_resource("rmarkdown/resources/ReyesStyleDoc.docx")

  # call the base word_document function
  rmarkdown::word_document(
    reference_docx = wordstyle,
    ...
  )
}


#' Custom html template.
#'
#' Loads additional style file for html for MA382.
#'
#' @param ... additional arguments provided to \@code{html_document}.
#'
#' @export
ma382_html_format <- function(...) {
  # locations of resource files in the package
  pkg_resource <- function(...) {
    system.file(..., package = "reyes382")
  }

  cssstyle <- pkg_resource("rmarkdown/resources/ReyesStyles.css")

  # call the base word_document function
  rmarkdown::html_document(
    css = cssstyle,
    theme = "readable",
    highlight = "tango",
    ...
  )
}
