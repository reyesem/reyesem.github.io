#' Additional functionality for MA382 Intro Stats at RHIT.
#'
#' Additional functions useful in the analysis of data, which are not readily
#' available in standard packages, are provided here. These are used in the
#' Introduction to Statistics course at Rose-Hulman Institute of Technology.
"_PACKAGE"
