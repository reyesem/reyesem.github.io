# Code for implementing a simulation investigating ANOVA.


#' ANOVA Investigation.
#'
#' Perform a simulation in order to investigate the sampling distribution of the
#' standardized statistic from ANOVA.
#'
#' @param means vector of the group population means. Note, the number of groups
#'   is determined from the length of \code{means}.
#' @param n vector of sample sizes to consider (default = 10). Same sample size
#'   is used for each group. So, total sample size is \code{n * length(means)}.
#' @param sigma vector of error standard deviations to consider (default = 1).
#'   The same standard deviation is used within each group.
#' @param m scalar representing the number of replications (default = 5000).
#'
#' @return A dataframe.
#'
#' @import stats
#' @export
Simulate_ANOVA <- function(means,
                           n = 10,
                           sigma = 1,
                           m = 5000) {
  # Error checks
  if (length(means) == 1) {
    stop("length of means must be larger than 1")
  }

  if (any((n <- floor(n)) < 1)) {
    stop("sample sizes must be at least 1 per group")
  }

  if (any(sigma <= 0)) {
    stop("error standard deviations must be positive")
  }


  # Storage of simulation results
  out <- tidyr::expand_grid(
    n = n,
    sigma = sigma,
    m = seq(m)
  )


  # Conduct simulation
  out <- out |>
    dplyr::mutate(
      anova = purrr::map2(n, sigma, function(x, y) {
        df <- generate_anova(means, x, y)
        m1 <- lm(Response ~ Group, data = df)

        anova(m1)
        }),
      statistic = purrr::map_dbl(anova, ~ .x$`F value`[1]),
      pvalue = purrr::map_dbl(anova, ~ .x$`Pr(>F)`[1])
  ) |>
    dplyr::select(-anova)

  out
}

