# Code for implementing a simulation investigating the CLT.


#' Sampling Distribution Investigation.
#'
#' Perform a simulation in order to investigate the sampling distribution of a
#' simple statistic.
#'
#' @param stat the name of a function which computes the statistic of interest.
#'   The function must take a single vector as an input and return a scalar.
#' @param rfun the name of the function which generates a sample of size n.
#' @param n vector of sample sizes to consider (default = c(5, 10, 30, 100)).
#' @param m scalar representing the number of replications (default = 10000).
#' @param ... additional arguments to pass to rfun.
#'
#' @return A dataframe.
#'
#' @import stats
#' @export
Simulate_Sampling_Distribution <- function(stat,
                                           rfun,
                                           n = c(5, 10, 30, 100),
                                           m = 10000,
                                           ...) {

  # Storage of simulation results
  out <- tidyr::expand_grid(
    n = n,
    m = seq(m)
  )


  # Generate results
  out <- out |>
    dplyr::mutate(
      statistic = purrr::map_dbl(n, function(x) stat(rfun(x, ...)))
    )


  return(out)
}


#' Plot Sampling Distribution
#'
#' Plot the results of a sampling distribution with a theoretical model
#' overlayed.
#'
#' @param object results from using
#'   \code{Simulate_Sampling_Distribution}
#' @param model function for constructing the density of the model
#' @param ... additional arguments to pass to \code{model}.
#'
#' @import ggplot2
#' @import stats
#' @importFrom rlang .data
#' @export
Plot_Sampling_Distribution <- function(object,
                                       model = dnorm,
                                       ...) {
  out <- ggplot(data = object,
         mapping = aes(x = .data$statistic)) +
    geom_histogram(aes(y = after_stat(density)),
                   bins = 30, color = "black", fill = "grey75") +
    geom_function(fun = model,
                  args = list(...),
                  color = "blue") +
    facet_wrap(~ n, labeller = purrr::partial(label_both, sep = " = ")) +
    labs(x = "Value of Statistic",
         y = "Density")

  return(out)
}
