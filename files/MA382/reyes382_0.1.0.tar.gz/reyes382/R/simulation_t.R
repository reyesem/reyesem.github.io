# Code for implementing a shiny app showing t-distribution in regression.


#' Sampling Distribution of Least Squares Estimates.
#'
#' Perform a simulation in order to investigate the sampling distribution of the
#' least squares estimates.
#'
#' @import shiny
#' @import stats
#' @importFrom rlang .data
#' @export
Least_Squares_Sampling_Distribution <- function() {

  shinyApp(
    ui = fluidPage(
      withMathJax(),
      sidebarLayout(
        sidebarPanel(
          p('Enter the values of the parameters that specify the model for ',
            'the data generating process.'),
          helpText('Enter the size of the sample to generate.'),
          sliderInput('n', 'Sample Size', min = 5, max = 100, value = 5,
                      step = 5, round = TRUE),
          br(),
          helpText('Enter the values for the parameters in the mean model.'),
          numericInput('b0', 'Intercept', 0),
          numericInput('b1', 'Slope', 0),
          br(),
          helpText('Enter a value for the standard deviation of the error ',
                   'term.'),
          numericInput('s', 'Error SD (\\(\\sigma\\))', 1, min = 0)),
        mainPanel(
          p('We will be considering data generated according to the model'),
          p('\\[y_i = \\beta_0 + \\beta_1 x_i + \\varepsilon_i\\]'),
          p('where \\(\\varepsilon_i \\sim N\\left(0, \\sigma^2\\right)\\).'),
          br(),
          p('Here is an example of the type of data you have chosen to ',
            'generate based on the chosen values of the parameters.'),
          plotOutput('scatter'),
          br(),
          br(),
          p('Based on resampling from the population 1000 times, below ',
            'is a representation of the sampling distribution of the ',
            'least squares parameter estimates on their original scale.'),
          plotOutput('estimates'),
          br(),
          br(),
          p('Instead of examining the original scale, we also examine ',
            'the sampling distribution of the standardized least squares ',
            'estimates.  You can optionally overlay two different ',
            'theoretical models on the graphic.'),
          br(),
          helpText('Check the box to overlay a Normal distribution, and ',
                   'then provide the parameters for the Normal curve.'),
          checkboxInput('normal', "Overlay Normal Distribution", FALSE),
          numericInput('normalmean', 'Mean of Normal Distribution', 0),
          numericInput('normalsd', 'Standard Deviation of Normal Distribution',
                       1, min = 0),
          br(),
          helpText('Check the box to overlay a t-distribution, and ',
                   'then provide the degrees of freedom for the curve.'),
          checkboxInput('t', 'Overlay t-distribution', FALSE),
          numericInput('tdf', 'Degrees of Freedom', value = 1, min = 1),
          br(),
          plotOutput('standardized'))
      )
    ),

    server = function(input, output) {
      # Create data with model summaries
      generated_data <- reactive({
        tidyr::expand_grid(
          m = seq(1000),
          sample = list(dplyr::tibble(x = runif(input$n, min = 0, max = 10)))
        ) |>
          dplyr::mutate(sample = purrr::map(.data$sample, function(df) {
            df$y <- input$b0 + input$b1 * df$x +
              rnorm(input$n, mean = 0, sd = input$s)

            df
          })) |>
          dplyr::mutate(model = purrr::map(.data$sample, function(df) {
            lm(y ~ x, data = df)
          })) |>
          dplyr::mutate(Intercept = purrr::map_dbl(.data$model, ~ coef(.x)[1]),
                 SE_Intercept = purrr::map_dbl(.data$model, ~ sqrt(vcov(.x)[1,1])),
                 Slope = purrr::map_dbl(.data$model, ~ coef(.x)[2]),
                 SE_Slope = purrr::map_dbl(.data$model, ~ sqrt(vcov(.x)[2,2])))
      })


      # Visualize example dataset
      output$scatter <- renderPlot({
        ggplot2::ggplot(data = generated_data()$sample[[1]],
               mapping = ggplot2::aes(y = .data$y, x = .data$x)) +
          ggplot2::geom_point() +
          ggplot2::geom_abline(slope = input$b1,
                      intercept = input$b0) +
          ggplot2::labs(y = "Response",
               x = "Predictor",
               title = "Example sample generated from true model.") +
          ggplot2::theme_minimal()
      })


      # Visualize sampling distribution of Intercept and Slope
      output$estimates <- renderPlot({
        generated_data() |>
          dplyr::select(.data$Intercept, .data$Slope) |>
          tidyr::pivot_longer(cols = c("Intercept", "Slope"),
                       names_to = "Parameter",
                       values_to = "Estimate") |>
          ggplot2::ggplot(mapping = ggplot2::aes(x = .data$Estimate)) +
          ggplot2::geom_histogram(bins = 30,
                         color = 'black',
                         fill = 'grey75') +
          ggplot2::labs(x = "Estimated Value of the Parameter",
               y = NULL) +
          ggplot2::theme_minimal() +
          ggplot2::theme(axis.text.y = ggplot2::element_blank(),
                axis.ticks.y = ggplot2::element_blank()) +
          ggplot2::facet_wrap(~ .data$Parameter, scales = "free")
      })


      # Visualize sampling distribution of standardized estimates
      output$standardized <- renderPlot({
        base <- generated_data() |>
          dplyr::mutate(Intercept = (.data$Intercept - input$b0) / .data$SE_Intercept,
                 Slope = (.data$Slope - input$b1) / .data$SE_Slope) |>
          dplyr::select(.data$Intercept, .data$Slope) |>
          tidyr::pivot_longer(cols = c("Intercept", "Slope"),
                       names_to = "Parameter",
                       values_to = "Estimate") |>
          ggplot2::ggplot(mapping = ggplot2::aes(x = .data$Estimate)) +
          ggplot2::geom_histogram(ggplot2::aes(y = ggplot2::after_stat(density)),
                         bins = 30,
                         color = 'black',
                         fill = 'grey75') +
          ggplot2::labs(x = 'Standardized Least Squares Estimate',
               y = NULL) +
          ggplot2::theme_minimal() +
          ggplot2::theme(axis.text.y = ggplot2::element_blank(),
                axis.ticks.y = ggplot2::element_blank()) +
          ggplot2::facet_wrap(~ .data$Parameter, scales = "fixed")

        if (input$normal) {
          base <- base +
            ggplot2::geom_function(fun = dnorm,
                          color = "blue",
                          size = 1.1,
                          args = list(mean = input$normalmean,
                                      sd = input$normalsd))
        }

        if (input$t) {
          base <- base +
            ggplot2::geom_function(fun = dt,
                          color = "darkgreen",
                          size = 1.1,
                          args = list(df = input$tdf))
        }

        base
      })
    }
  )
}


