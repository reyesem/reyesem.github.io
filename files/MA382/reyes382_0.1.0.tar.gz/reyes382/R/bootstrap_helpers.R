# functions for simplifying the use of the lmboot package.

#' Summarize bootstrap sampling distributions.
#'
#' Extract the bootstrap replicates from the output of \code{lmboot} functions
#' \code{residual.boot}, \code{wild.boot}, or \code{ANOVA.boot} and summarize
#' the distributions.
#'
#' @param object result from call to \code{residual.boot} or \code{wild.boot}.
#'
#' @return dataframe of the style of \code{broom} package storing the various
#' summaries.
#'
#' @import stats
#' @importFrom rlang .data
#' @export
summarise_lmboot <- function(object) {
  if (is.null(object$origFStats)) {
    df <- object$bootEstParam |>
      tidyr::as_tibble()
  } else {
    df <- object$bootFStats |>
      tidyr::as_tibble(
        .name_repair =
          function(x) stringr::str_trim(object$terms[-length(object$terms)])
      )
  }

  df |>
    tidyr::pivot_longer(cols = tidyr::everything(),
                        names_to = "term",
                        values_to = "value") |>
    dplyr::group_by(.data$term) |>
    dplyr::summarise(
      Min = min(.data$value),
      Median = median(.data$value),
      Mean = mean(.data$value),
      Max = max(.data$value),
      IQR = IQR(.data$value),
      StdErr = sd(.data$value)
    )
}

#' Compute percentile confidence intervals using results from lmboot package.
#'
#' Extract the bootstrap replicates from the output of \code{lmboot} functions
#' \code{residual.boot} and \code{wild.boot} and construct confidence intervals.
#'
#' @param object result from call to \code{residual.boot} or \code{wild.boot}.
#' @param level confidence level (default = 0.95).
#'
#' @return dataframe of the style of \code{broom} package storing the CI's of
#' each parameter.
#'
#' @import stats
#' @importFrom rlang .data
#' @export
ci_lmboot <- function(object, level = 0.95) {
  if (level < 0) {
    stop("level must be between 0 and 1.")
  } else if (level > 1) {
    level <- level / 100

    warning("level converted to a value between 0 and 1")
  }

  object$bootEstParam |>
    tidyr::as_tibble() |>
    tidyr::pivot_longer(cols = tidyr::everything(),
                        names_to = "term",
                        values_to = "value") |>
    dplyr::group_by(.data$term) |>
    dplyr::summarise(
      conf.low =
        quantile(.data$value, prob = 0.5 * (1 - level), names = FALSE),
      conf.high =
        quantile(.data$value, prob = 0.5 * (1 + level), names = FALSE)
    )
}




#' Plot the bootstrap sampling distribution from lmboot package.
#'
#' Extract the bootstrap replicates from the output of \code{lmboot} functions
#' \code{residual.boot} and \code{wild.boot} and plot the distributions.
#'
#' @param object result from call to \code{residual.boot} or \code{wild.boot}.
#'
#' @importFrom rlang .data
#' @export
plot_lmboot <- function(object) {
  origEst <- data.frame(
    term = rownames(object$origEstParam),
    value = object$origEstParam[, 1]
  )


  object$bootEstParam |>
    tidyr::as_tibble() |>
    tidyr::pivot_longer(cols = tidyr::everything(),
                        names_to = "term",
                        values_to = "value") |>
    dplyr::group_by(.data$term) |>
    ggplot2::ggplot(mapping = ggplot2::aes(x = .data$value)) +
    ggplot2::geom_density(size = 1.1) +
    ggplot2::geom_vline(data = origEst,
                        mapping = ggplot2::aes(xintercept = .data$value),
                        linetype = 2) +
    ggplot2::labs(y = NULL,
                  x = "Estimate of Parameter") +
    ggplot2::facet_wrap(~ .data$term, scales = "free") +
    ggplot2::theme_minimal() +
    ggplot2::theme(axis.text.y = ggplot2::element_blank(),
                   axis.ticks.y = ggplot2::element_blank())
}



#' Bootstrap ANOVA table.
#'
#' Extract the bootstrap replicates from the output of \code{lmboot} functions
#' \code{ANOVA.boot} and report the results in an ANOVA-table format.
#'
#' @param object result from call to \code{ANOVA.boot}.
#'
#' @return dataframe of the style of \code{broom} package storing the various
#' summaries.
#'
#' @export
anova_lmboot <- function(object) {
  dplyr::tibble(
    term = stringr::str_trim(object$terms),
    df = object$df,
    sumsq = c(object$origSSTr, object$origSSE),
    meansq = c(object$origSSTr, object$origSSE) / object$df,
    statistic = c(object$origFStats, NA),
    p.value = c(object$`p-values`, NA)
  )
}


#' Plot the null distribution of standardized statistic from lmboot package.
#'
#' Extract the bootstrap replicates from the output of \code{lmboot} functions
#' \code{ANOVA.boot} and plot the null distribution.
#'
#' @param object result from call to \code{ANOVA.boot}.
#'
#' @importFrom rlang .data
#' @export
plot_f_lmboot <- function(object) {
  df <- data.frame(
    statistic = c(object$bootFStats),
    term = rep(stringr::str_trim(object$terms[-length(object$terms)]),
               each = ifelse(length(object$origFStats) > 1,
                             nrow(object$bootFStats),
                             length(object$bootFStats)))
  )

  origFs <- data.frame(
    term = stringr::str_trim(object$terms[-length(object$terms)]),
    value = object$origFStats
  )

  df |>
    ggplot2::ggplot(mapping = ggplot2::aes(x = .data$statistic)) +
    ggplot2::geom_density(size = 1.1) +
    ggplot2::geom_vline(data = origFs,
                        mapping = ggplot2::aes(xintercept = .data$value),
                        linetype = 2) +
    ggplot2::labs(y = NULL,
                  x = "Value of Standardized Statistic") +
    ggplot2::facet_wrap(~ .data$term, scales = "free") +
    ggplot2::theme_minimal() +
    ggplot2::theme(axis.text.y = ggplot2::element_blank(),
                   axis.ticks.y = ggplot2::element_blank())
}
