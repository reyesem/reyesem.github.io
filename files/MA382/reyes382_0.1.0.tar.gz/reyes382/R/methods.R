# Additional methods for common operations.

#' Summarize a dataset.
#'
#' Wrapper for \code{\link[skimr]{skim}} which returns numeric summaries for
#' variables in a dataset.
#'
#' @param data see \code{\link[skimr]{skim}}
#' @param ... see \code{\link[skimr]{skim}}.
#'
#' @export
skim_clean <- skimr::skim_with(
  numeric = skimr::sfl(hist = NULL),
  ts = skimr::sfl(line_graph = NULL),
  character = skimr::sfl(
    min = NULL,
    max = NULL,
    empty = NULL,
    n_unique = skimr::n_unique,
    whitespace = NULL,
    top_counts = NULL,
    counts = ~paste(names(skimr::sorted_count(.)),
                    skimr::sorted_count(.),
                    sep = ":", collapse = ", "),
    percs = ~paste(names(skimr::sorted_count(.)),
                   round(100*skimr::sorted_count(.)/skimr::n_complete(.), 1),
                   sep = ":", collapse = ", ")),
  factor = skimr::sfl(
    top_counts = NULL,
    counts = ~paste(names(skimr::sorted_count(.)),
                    skimr::sorted_count(.),
                    sep = ":", collapse = ", "),
    percs = ~paste(names(skimr::sorted_count(.)),
                   round(100*skimr::sorted_count(.)/skimr::n_complete(.), 1),
                   sep = ":", collapse = ", ")))

