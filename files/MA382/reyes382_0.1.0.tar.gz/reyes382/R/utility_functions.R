### Copy functions needed, but not exported from other packages.

# knitr:::split_lines
split_lines <- function(x) {
  if (length(grep("\n", x)) == 0L)
    return(x)
  x = gsub("\n$", "\n\n", x)
  x[x == ""] = "\n"
  unlist(strsplit(x, "\n"))
}



### Personal helper functions

# function: generate_anova
# description: generate a dataset according to an ANOVA model
generate_anova <- function(means, n, sigma) {
  k <- length(means)

  x <- stringr::str_pad(seq(k),
                        width = nchar(k),
                        side = "left",
                        pad = "0")

  x <- rep(paste0("Group", x), each = n)

  y <- rnorm(k * n, mean = 0, sd = sigma) +
    rep(means, each = n)

  dplyr::tibble(
    Group = x,
    Response = y
  )
}
