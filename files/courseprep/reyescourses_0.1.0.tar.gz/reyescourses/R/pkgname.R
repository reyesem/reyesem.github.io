#' Additional functionality for courses taught by Prof. Reyes at RHIT.
#'
#' Additional functions useful when performing data analysis that are not
#' readily available in standard packages.  These are used in advanced courses
#' taught by Prof. Reyes at Rose-Hulman Institute of Technology.
"_PACKAGE"
