# Functions helpful for working with stan.

#' Tidy Results from Stan
#'
#' Convert the parameter arguments from stan to a tibble for tidier viewing.
#'
#' @param object a \code{\link[rstan]{stanfit}} model object (see
#'   \code{\link[rstan]{extract}}).
#' @param include_warmup boolean indicating whether the draws from the warmup
#'   period should be included (default = \code{TRUE}).
#'
#' @return a \code{\link[tibble]{tibble}}.
#'
#' @seealso \code{\link[rstan]{extract}}
#'
#' @examples
#' \dontrun{
#' ## Not run:
#' ex_model_code <- '
#'   parameters {
#'     real alpha[2,3];
#'     real beta[2];
#'   }
#'   model {
#'     for (i in 1:2) for (j in 1:3)
#'       alpha[i, j] ~ normal(0, 1);
#'     for (i in 1:2)
#'       beta ~ normal(0, 2);
#'   }
#' '
#'
#' ## fit the model
#' fit <- rstan::stan(model_code = ex_model_code, chains = 4)
#'
#' ## extract alpha and beta with 'permuted = TRUE'
#' fit_ss <- stan_to_df(fit, permuted = TRUE)
#' }
#'
#' @export
stan_to_df <- function(object, include_warmup = FALSE){
  if (!requireNamespace('rstan', quietly = TRUE)) {
    stop('Package "rstan" needed for this function to work. Please install it.',
         call. = FALSE)
  }

  params <- rstan::extract(object,
                           permuted = FALSE,
                           inc_warmup = TRUE)

  col.names <- dimnames(params)$parameters

  params <-
    do.call(apply(params, 3, function(u){
      tibble::tibble(
        `_Value` = c(u),
        `_Chain` = rep(seq_along(dimnames(u)[[2]]),
                       each = nrow(u)),
        `_Iteration` = rep(seq(nrow(u)),
                           times = length(dimnames(u)[[2]])))}),
      what = 'cbind')

  params <-
    cbind(dplyr::select(params, tidyselect::contains('_Value')),
          paste0('chain:', params[, ncol(params) - 1]),
          params[, ncol(params)]) |>
    tibble::as_tibble()

  colnames(params) <- c(col.names, '.chain', '.iteration')

  if (!include_warmup) {
    params <- params[params$`.iteration` > object@sim$warmup, ]
  } else {
    params$`.warmup` <-
      params$`.iteration` <= object@sim$warmup
  }

  params
}
