# Functions that help with setting things up

# function: course_setup
# description: personal function for getting things started in the class.

course_setup <- function(course){
  # locations of resource files in the package
  pkg_resource <- function(...) {
    system.file(..., package = 'reyescourses')
  }

  setup <- pkg_resource(paste0('exec/', tolower(course), 'setup.R'))

  source(setup)
}
