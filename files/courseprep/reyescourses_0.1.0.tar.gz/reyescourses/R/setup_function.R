# Function: course_setup
# Description: personal function for students in each course so that all
#              necessary functionality is incorporated.

course_setup <- function(course){
  # locations of resource files in the package
  pkg_resource <- function(...) {
    system.file(..., package = 'reyescourses')
  }

  setup <- pkg_resource(paste0('exec/', tolower(course), 'setup.R'))

  source(setup)
}

