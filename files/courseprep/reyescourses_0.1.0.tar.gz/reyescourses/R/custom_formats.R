#' Custom Word template.
#'
#' Loads additional style file for Word.
#'
#' @param ... additional arguments provided to \code{word_document}.
#'
#' @export
rhit_word_document <- function(...) {
  # locations of resource files in the package
  pkg_resource <- function(...) {
    system.file(..., package = 'reyescourses')
  }

  wordstyle <- pkg_resource('rmarkdown/resources/ReyesStyleDoc.docx')

  # call the base word_document function
  rmarkdown::word_document(
    reference_docx = wordstyle,
    ...
  )
}


#' Custom HTML template.
#'
#' Loads additional style file for HTML.
#'
#' @param ... additional arguments provided to \code{html_document}.
#'
#' @export
rhit_html_document <- function(...) {
  # locations of resource files in the package
  pkg_resource <- function(...) {
    system.file(..., package = 'reyescourses')
  }

  htmlstyle <- pkg_resource('rmarkdown/resources/ReyesStyles.css')

  # call the base word_document function
  rmarkdown::html_document(
    css = htmlstyle,
    ...
  )
}


#' Custom Tex template.
#'
#' Loads additional style file for LaTeX.
#'
#' @param ... additional arguments provided to \code{pdf_document}.
#'
#' @export
rhit_pdf_document <- function(...) {
  # locations of resource files in the package
  pkg_resource <- function(...) {
    system.file(..., package = 'reyescourses')
  }

  pdfstyle <- pkg_resource('rmarkdown/resources/ReyesStyles.tex')

  # call the base word_document function
  rmarkdown::pdf_document(
    includes = rmarkdown::includes(
      in_header = pdfstyle
    ),
    ...
  )
}
