# Description: personal function for students in the course so that all
#              necessary functionality is incorporated.


## ---- Clean Slate ----
# Remove anything previously existing and start with clean slate
rm(list = ls(sorted=FALSE)[ls(sorted=FALSE) != "params"])
gc()

## ---- Load Packages ----
import::from(boot, boot)
import::from(car, Boot, linearHypothesis, .carEnv)
import::from(splines, ns)
import::from(rms, lsp, pol, rcs)
import::from(skimr, skim)
library(survival)
library(geepack)
library(lme4)
library(tidyverse)
library(broom)
library(broom.mixed)
library(reyescourses)


## ---- Change Options ----
# Suppress status bar in dplyr.
# Suppress messages from summarise about groups.
# Change handling of ordered factors
options(dplyr.show_progress = FALSE,
        dplyr.summarise.inform = FALSE,
        readr.show_col_types = FALSE,
        contrasts = rep("contr.treatment", 2))


# Change theme for plots
theme_set(theme_bw(14))
theme_update(legend.position = "bottom",
             legend.box = "vertical")


# Specify chunk options
knitr::opts_chunk$set(
  prompt = FALSE,
  comment = "",
  out.width = ifelse(knitr::is_latex_output(), "0.8\\textwidth", "80%"),
  fig.align = "center",
  linewidth = 80)


## ---- Ensure Source Code Wraps ----
.hook_source = knitr::knit_hooks$get("source")

knitr::knit_hooks$set(
  source = function(x, options){
    # this hook is used only when linewidth option is not NULL
    if (!is.null(n <- options$linewidth)){
      x = reyescourses:::split_lines(x)

      x = ifelse(nchar(x) > n, stringr::str_wrap(x, width = n, exdent = 2), x)
    }

    .hook_source(x, options)
  })


