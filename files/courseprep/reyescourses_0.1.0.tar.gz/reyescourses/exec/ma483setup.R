# Description: personal function for students in the course so that all
#              necessary functionality is incorporated.


## ---- Clean Slate ----
# Remove anything previously existing and start with clean slate
rm(list = ls(sorted=FALSE)[ls(sorted=FALSE) != 'params'])
gc()

## ---- Load Packages ----
library(tidyverse)
library(broom)
library(broom.mixed)
library(HDInterval)
library(rstan)
library(rstanarm)
library(bayesplot)
library(bridgesampling)
library(reyescourses)


## ---- Change Options ----
# Suppress status bar in dplyr.
# Suppress messages from summarise about groups.
# Change handling of ordered factors
options(dplyr.show_progress = FALSE,
        dplyr.summarise.inform = FALSE,
        contrasts = rep('contr.treatment', 2))


# Use multiple cores for rstan
options(mc.cores = (parallel::detectCores() - 2))


# Change theme for plots
theme_set(theme_bw(12))
theme_update(legend.position = 'bottom',
             legend.box = 'vertical')

rstan_ggtheme_options(
  legend.position = 'bottom',
  legend.box = 'vertical',
  panel.background = element_rect(fill = 'white',
                                  color = NA),
  panel.border = element_rect(fill = NA,
                              color = 'grey20'),
  legend.key = element_rect(fill = 'white',
                            color = NA),
  complete = TRUE
)


# Specify chunk options
knitr::opts_chunk$set(
  prompt = FALSE,
  comment = '',
  linewidth = 80)


## ---- Ensure Source Code Wraps ----
.hook_source = knitr::knit_hooks$get('source')

knitr::knit_hooks$set(
  source = function(x, options){
    # this hook is used only when linewidth option is not NULL
    if (!is.null(n <- options$linewidth)){
      x = reyescourses:::split_lines(x)

      x = ifelse(nchar(x) > n, stringr::str_wrap(x, width = n, exdent = 2), x)
    }

    .hook_source(x, options)
  })

