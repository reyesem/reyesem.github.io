# Description: personal function for students in the course so that all
#              necessary functionality is incorporated.


## ---- Clean Slate ----
# Remove anything previously existing and start with clean slate
rm(list = ls(sorted=FALSE)[ls(sorted=FALSE) != "params"])
gc()

## ---- Load Packages ----
import::from(skimr, skim)
library(tidyverse)
library(survey)
library(srvyr)
library(rsample)
library(broom)
library(reyescourses)


## ---- Change Options ----
# Suppress status bar in dplyr.
# Suppress messages from summarise about groups.
# Change handling of ordered factors
options(dplyr.show_progress = FALSE,
        dplyr.summarise.inform = FALSE,
        readr.show_col_types = FALSE,
        contrasts = rep("contr.treatment", 2))


# Change theme for plots
theme_set(theme_minimal(14))
theme_update(legend.position = "bottom",
             legend.box = "vertical")



## ---- Ensure Source Code Wraps ----
.hook_source = knitr::knit_hooks$get("source")

knitr::knit_hooks$set(
  source = function(x, options){
    # this hook is used only when linewidth option is not NULL
    if (!is.null(n <- options$linewidth)){
      x = reyescourses:::split_lines(x)

      x = ifelse(nchar(x) > n, stringr::str_wrap(x, width = n, exdent = 2), x)
    }

    .hook_source(x, options)
  })


