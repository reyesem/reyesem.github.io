## ----setup, include=FALSE-----------------------------------------------------
reyescourses:::course_setup('MA482')

## ----data, echo=FALSE---------------------------------------------------------
mtcars %>%
  head() %>%
  knitr::kable(digits = 3)

## ----packages, eval=FALSE, echo=TRUE------------------------------------------
#  reyescourses:::course_setup('MA482')

## ---- echo=FALSE, eval=TRUE---------------------------------------------------
cat("```{r}","\n", "Code goes here...","\n", "```", "\n", sep="")

## ---- echo=TRUE, eval=FALSE---------------------------------------------------
#  # Comments (not evaluated) begin with a hashtag.
#  ObjectName <- code to generate results

## ---- echo=TRUE, eval=FALSE---------------------------------------------------
#  ObjectTwo <- ObjectOne %>%
#    summarise()

## ---- echo=TRUE, eval=FALSE---------------------------------------------------
#  demographics <- tibble(
#    `Hair Color` = c("Black", "Black", "Brown", "Blonde", "Black"),
#    Age = c(20, 19, 21, 20, 20)
#  )

## ----mutate-------------------------------------------------------------------
mtcars <- mtcars %>%
  mutate(Gallons_per_Mile = 1/mpg)

## ---- echo=FALSE--------------------------------------------------------------
mtcars %>%
  head() %>%
  knitr::kable(digits = 3)

## ----arrange------------------------------------------------------------------
mtcars <- mtcars %>%
  arrange(cyl)

## ---- echo=FALSE--------------------------------------------------------------
mtcars %>%
  head() %>%
  knitr::kable(digits = 3)

## ----filter-------------------------------------------------------------------
automatic.only <- mtcars %>%
  filter(am == 0)

## ---- echo=FALSE--------------------------------------------------------------
automatic.only %>%
  head() %>%
  knitr::kable(digits = 3)

## ----factors------------------------------------------------------------------
mtcars <- mtcars %>%
  mutate(am = recode(am, 
                     `0` = "automatic",
                     `1` = "manual"))

## ---- echo=FALSE--------------------------------------------------------------
mtcars %>%
  head() %>%
  knitr::kable(digits = 3)

## ----factors-cont-------------------------------------------------------------
mtcars <- mtcars %>%
  mutate(am = recode(am, 
                     "automatic" = "Automatic Transmission",
                     "manual" = "Manual Transmission"))

## ----skim-example-------------------------------------------------------------
skim_clean(mtcars)

## ----skim-grp-----------------------------------------------------------------
mtcars %>%
  group_by(am) %>%
  skim_clean()

## ----bar-chart----------------------------------------------------------------
ggplot(data = mtcars,
       mapping = aes(x = am)) +
  geom_bar() +
  labs(x = "",
       y = "Frequency")

## -----------------------------------------------------------------------------
mtcars <- mtcars %>%
  mutate(vs = recode(vs,
                     `0` = "V Engine",
                     `1` = "Straight Engine"))

## ----double-bar-chart---------------------------------------------------------
ggplot(data = mtcars,
       mapping = aes(x = am, fill = vs)) +
  geom_bar() +
  labs(x = "",
       fill = "",
       y = "Frequency")

## ----histogram-1--------------------------------------------------------------
ggplot(data = mtcars,
       mapping = aes(x = mpg)) +
  geom_histogram(binwidth = 1) +
  labs(x = "Miles per Gallon",
       y = "Frequency")

## ----histogram-2--------------------------------------------------------------
ggplot(data = mtcars,
       mapping = aes(x = mpg)) +
  geom_histogram(binwidth = 3) +
  labs(x = "Miles per Gallon",
       y = "Frequency")

## ----histogram-3--------------------------------------------------------------
ggplot(data = mtcars,
       mapping = aes(x = mpg)) +
  geom_histogram() +
  labs(x = "Miles per Gallon",
       y = "Frequency")

## ----density-plot-------------------------------------------------------------
ggplot(data = mtcars,
       mapping = aes(x = mpg)) +
  geom_density() +
  labs(x = "Miles per Gallon",
       y = "Density")

## ----box-plot-----------------------------------------------------------------
ggplot(data = mtcars,
       mapping = aes(y = mpg, x = "")) +
  geom_boxplot() +
  labs(y = "Miles per Gallon",
       x = "")

## ----boxplot-1----------------------------------------------------------------
ggplot(data = mtcars,
       mapping = aes(y = mpg, x = am)) +
  geom_boxplot() +
  labs(y = "Miles per Gallon",
       x = "")

## ----violin-plots-------------------------------------------------------------
ggplot(data = mtcars,
       mapping = aes(y = mpg, x = am)) +
  geom_violin() +
  labs(y = "Miles per Gallon",
       x = "")

## ----ivp----------------------------------------------------------------------
ggplot(data = mtcars,
       mapping = aes(y = mpg, x = am)) +
  geom_point() +
  labs(y = "Miles per Gallon",
       x = "")

## ----jitter-------------------------------------------------------------------
ggplot(data = mtcars,
       mapping = aes(y = mpg, x = am)) +
  geom_jitter(height = 0, width = 0.2) +
  labs(y = "Miles per Gallon",
       x = "")

## ----boxplot-2----------------------------------------------------------------
ggplot(data = mtcars,
       mapping = aes(y = mpg, x = am, fill = vs)) +
  geom_boxplot() +
  labs(y = "Miles per Gallon",
       x = "",
       fill = "")

## ----scatterplot-1------------------------------------------------------------
ggplot(data = mtcars,
       mapping = aes(y = mpg, x = wt)) +
  geom_point() +
  labs(y = "Miles Per Gallon",
       x = "Weight (1000 lbs)")

## ----scatterplot-2------------------------------------------------------------
ggplot(data = mtcars,
       mapping = aes(y = mpg, x = wt, color = am)) +
  geom_point() +
  labs(y = "Miles Per Gallon",
       x = "Weight (1000 lbs)",
       color = "")

## ----scatterplot-3------------------------------------------------------------
ggplot(data = mtcars,
       mapping = aes(y = mpg, x = wt, shape = am)) +
  geom_point() +
  labs(y = "Miles Per Gallon",
       x = "Weight (1000 lbs)",
       shape = "")

## ----scatterplot-4------------------------------------------------------------
ggplot(data = mtcars,
       mapping = aes(y = mpg, x = wt, color = hp)) +
  geom_point() +
  labs(y = "Miles Per Gallon",
       x = "Weight (1000 lbs)",
       color = "Horsepower")

## ----scatterplot-5------------------------------------------------------------
ggplot(data = mtcars,
       mapping = aes(y = mpg, x = wt, size = hp)) +
  geom_point() +
  labs(y = "Miles Per Gallon",
       x = "Weight (1000 lbs)",
       size = "Horsepower")

## ----prob-t-------------------------------------------------------------------
1 - pt(2.67, df = 29)

## ----prob-norm----------------------------------------------------------------
qnorm(0.975, mean = 0, sd = 1)

## ----lm-mpg-------------------------------------------------------------------
fit.mtcars <- lm(mpg ~ am + wt, data = mtcars)

## ----lm-mpg-tidy--------------------------------------------------------------
tidy(fit.mtcars, conf.int = TRUE, conf.level = 0.95)

## ----lm-mpg-glance------------------------------------------------------------
glance(fit.mtcars)

## ----reg-augment--------------------------------------------------------------
mtcars.augment <- augment(fit.mtcars, data = mtcars)

## ---- echo=FALSE--------------------------------------------------------------
mtcars.augment %>%
  head() %>%
  knitr::kable(digits = 3)

## ----reg-time-series----------------------------------------------------------
ggplot(data = mtcars.augment,
       mapping = aes(y = .resid, x = seq_along(.resid))) +
  geom_point() +
  geom_line() +
  labs(y = "Residuals",
       x = "Order of Observations")

## ----reg-resid-1--------------------------------------------------------------
ggplot(data = mtcars.augment,
       mapping = aes(y = .resid, x = .fitted)) +
  geom_point() +
  labs(y = "Residuals",
       x = "Fitted Values")

## ----reg-resid-2--------------------------------------------------------------
ggplot(data = mtcars.augment,
       mapping = aes(y = .resid, x = .fitted)) +
  geom_point() +
  geom_smooth() +
  labs(y = "Residuals",
       x = "Fitted Values")

## ----reg-prob-plot------------------------------------------------------------
ggplot(data = mtcars.augment,
       mapping = aes(sample = .resid)) +
  stat_qq() +
  stat_qq_line() +
  labs(y = "Sample Quantiles",
       x = "Theoretical Quantiles")

## ----reg-linearity------------------------------------------------------------
ggplot(data = mtcars.augment,
       mapping = aes(y = .resid, x = wt)) +
  geom_point() +
  labs(y = "Residuals",
       x = "Weight of Vehicle (lbs)")

## ----lm-cat-------------------------------------------------------------------
fit2.mtcars <- lm(mpg ~ wt + am, data = mtcars)

tidy(fit2.mtcars, conf.int = TRUE, conf.level = 0.95)

## ----lm-indicators------------------------------------------------------------
mtcars <- mtcars %>%
  mutate(Manual = ifelse(am=="Manual Transmission", 1, 0))

fit3.mtcars <- lm(mpg ~ wt + Manual, data = mtcars)

tidy(fit3.mtcars, conf.int = TRUE, conf.level = 0.95)

## ----lm-interaction-----------------------------------------------------------
fit4.mtcars <- lm(mpg ~ wt + hp + wt:hp, data = mtcars)

tidy(fit4.mtcars, conf.int = TRUE, conf.level = 0.95)

## ----K-matrix-----------------------------------------------------------------
K <- matrix(
  c(0, 1, 0, 0,
    0, 0, 1, 0,
    0, 0, 0, 1),
  nrow = 3, ncol = 4, byrow = TRUE
)

## ----m-vector-----------------------------------------------------------------
m <- c(0, 0, 0)

## ----lm-linearhypothesis------------------------------------------------------
linearHypothesis(fit4.mtcars, K, rhs = m)

## ----confint-matrix-----------------------------------------------------------
confint(K, coef. = coef(fit4.mtcars), vcov. = vcov(fit4.mtcars))

## ----lm-boot------------------------------------------------------------------
mtcars.boot <- Boot(fit.mtcars, R = 3000, method = "residual")

confint(mtcars.boot, level = 0.95)

## ----lm-splines---------------------------------------------------------------
fit5.mtcars <- lm(mpg ~ am + lsp(wt, c(3, 4)), data = mtcars)

tidy(fit5.mtcars)

## ----lm-rcs-------------------------------------------------------------------
fit6.mtcars <- lm(mpg ~ am + rcs(wt, 5), data = mtcars)

tidy(fit6.mtcars)

## ---- echo=FALSE--------------------------------------------------------------
ChickWeight %>%
  head() %>%
  knitr::kable(digits = 3)

## ----spaghetti----------------------------------------------------------------
ggplot(data = ChickWeight,
       mapping = aes(y = weight, x = Time, color = Diet, group = Chick)) +
  geom_line() +
  labs(y = "Weight of Chick (g)",
       x = "Number of Days Since Birth",
       color = "Diet")

## ----mm-model-----------------------------------------------------------------
# Create indicator variables
chick <- ChickWeight %>%
  mutate(Diet2 = ifelse(Diet==2, 1, 0),
         Diet3 = ifelse(Diet==3, 1, 0),
         Diet4 = ifelse(Diet==4, 1, 0))

fit.chick <- lmer(weight ~ Time:Diet2 + Time:Diet3 + Time:Diet4 +
                    (Time | Chick), data = chick)

fit.chick

tidy(fit.chick)

## ----gee----------------------------------------------------------------------
chick <- chick %>%
  arrange(Chick, Time)

fit2.chick <- geeglm(weight ~ Time + Time:Diet2 + Time:Diet3 + Time:Diet4,
                     data = chick, id = Chick, corstr = "exchangeable")

fit2.chick

tidy(fit2.chick)

## ----dnase-subset-------------------------------------------------------------
DNase1 <- DNase %>%
  filter(Run==1)

## ----print-dnase, echo=FALSE--------------------------------------------------
head(DNase1)

## ----dnase-nls----------------------------------------------------------------
fit.dnase <- nls(density ~ beta1/(1 + exp((beta2 - conc)/beta3)), data = DNase1,
                 start = c("beta1" = 1.57, "beta2" = 2.41, "beta3" = 1.15))

tidy(fit.dnase)
glance(fit.dnase)

## ----dnase-ss-----------------------------------------------------------------
fit2.dnase <- nls(density ~ SSlogis(conc, Asym, xmid, scal), data = DNase1)

tidy(fit2.dnase)

## ----dnase-subset-2-----------------------------------------------------------
DNase2 <- DNase %>%
  filter(Run==1 | Run==2) %>%
  mutate(Run = recode(Run,
                      `1` = "Run 1",
                      `2` = "Run 2"))

## ----dnase-plot-2-------------------------------------------------------------
ggplot(data = DNase2,
       mapping = aes(y = density, x = conc, color = Run)) +
  geom_point() +
  geom_line() +
  labs(y = "Optical Density in the Assay",
       x = "Known Concentration of the Protein",
       color = "")

## ----dnase2-indicator---------------------------------------------------------
DNase2 <- DNase2 %>%
  mutate(Run2 = ifelse(Run=="Run 2", 1, 0))

## ----dnase2-formula-----------------------------------------------------------
dnase2.formula <- density ~ (b1 + b12*Run2)/(1 + exp((b2 - conc)/(b3 + b32*Run2)))

## ----dnase2-starts------------------------------------------------------------
# Starting values for Run 1
start.run1 <- getInitial(density ~ SSlogis(conc, Asym, xmid, scal),
                         data = filter(DNase2, Run=="Run 1"))

# Starting values for Run 2
start.run2 <- getInitial(density ~ SSlogis(conc, Asym, xmid, scal),
                         data = filter(DNase2, Run=="Run 2"))

# Create combined starting values
start.full <- c(start.run1,
                start.run2[1] - start.run1[1],
                start.run2[3] - start.run1[3])
names(start.full) <- c("b1", "b2", "b3", "b12", "b32")

## ----dnase2-fit---------------------------------------------------------------
fit.dnase2 <- nls(dnase2.formula, data = DNase2,
                  start = start.full)

tidy(fit.dnase2)

## ----dnase-pred-data----------------------------------------------------------
dnase.prediction <- expand.grid(conc = seq(0.01, 12.5, length.out = 1000))

## ----dnase-pred-augment-------------------------------------------------------
dnase.prediction <- augment(fit.dnase, newdata = dnase.prediction)

## ----dnase-pred-plot----------------------------------------------------------
ggplot() +
  geom_point(data = DNase1,
             mapping = aes(y = density, x = conc)) +
  geom_line(data = dnase.prediction,
            mapping = aes(y = .fitted, x = conc)) +
  labs(y = "Optical Density in the Assay",
       x = "Known Concentration of the Protein")

## ----dnase-1-summary, echo=FALSE----------------------------------------------
tidy(fit2.dnase, conf.int = TRUE)

## ----dnase-wild---------------------------------------------------------------
boot.dnase <- WildBoot(fit2.dnase)

confint(boot.dnase, type = "perc", level = 0.95)

## ---- echo=FALSE--------------------------------------------------------------
mtcars %>%
  head() %>%
  knitr::kable(digits = 3)

## ----logistic-fit-------------------------------------------------------------
fit.logistic <- glm((am=="Manual Transmission") ~ vs + mpg,
                    family = "binomial", data = mtcars)

tidy(fit.logistic, conf.int = TRUE)
glance(fit.logistic)

## ----logistic-or--------------------------------------------------------------
tidy(fit.logistic, conf.int = TRUE) %>%
  mutate(estimate = exp(estimate),
         conf.low = exp(conf.low),
         conf.high = exp(conf.high))

## ----logistic-model-fit-------------------------------------------------------
glance(fit.logistic)

## ----survival-data------------------------------------------------------------
hypertension <- tribble(
  ~`Years from Baseline`, ~`Risk`, ~`Deaths`, ~`Censored`,
   1, 146, 27,  3,
   2, 116, 18, 10,
   3,  88, 21, 10,
   4,  57,  9,  3,
   5,  45,  1,  3,
   6,  41,  2, 11,
   7,  28,  3,  5,
   8,  20,  1,  8,
   9,  11,  2,  1,
  10,   8,  2,  6
)

hypertension

## ----survival-lifetable-------------------------------------------------------
LifeTable(nrisk = Risk,
          nevent = Deaths,
          ncensor = Censored,
          data = hypertension)

## ----survival-lung------------------------------------------------------------
lung <- lung %>%
  mutate(status = status - 1,
         sex = recode(sex,
                      `1` = "Male",
                      `2` = "Female"))

## ----survival-kmest-----------------------------------------------------------
lung.km <- survfit(Surv(time, status) ~ sex, data = lung)

lung.km.tidy <- tidy(lung.km)

## ---- echo=FALSE--------------------------------------------------------------
head(lung.km.tidy)

## ----survival-tidy------------------------------------------------------------
lung.km.tidy <- lung.km.tidy %>%
  mutate(strata = recode(strata,
                         "sex=Female" = "Female",
                         "sex=Male" = "Male"))

## ----survival-lung-KMcurves---------------------------------------------------
ggplot(data = lung.km.tidy,
       mapping = aes(y = estimate, x = time, color = strata)) +
  geom_step(size = 1.25) +
  labs(y = "Survival",
       x = "Time (days)",
       color = "")

## ----survival-lung-km-estimate------------------------------------------------
lung.km.tidy %>%
  filter(strata=="Male", time==455)

## ----survival-bad-estimate----------------------------------------------------
lung.km.tidy %>%
  filter(strata=="Male", time==365)

## ----suvival-good-estimate----------------------------------------------------
lung.km.tidy %>%
  filter(strata=="Male", time<=365) %>%
  slice(nrow(.))

## ----survival-log-rank--------------------------------------------------------
lung.logrank <- survdiff(Surv(time, status) ~ sex, data = lung)

glance(lung.logrank)

## ----survival-coxph-----------------------------------------------------------
model.lung <- coxph(Surv(time, status) ~ sex + age + wt.loss, data = lung)

tidy(model.lung, conf.int = TRUE, conf.level = 0.95)

## ----survival-hr--------------------------------------------------------------
tidy(model.lung, conf.int = TRUE, conf.level = 0.95) %>%
  mutate(estimate = exp(estimate),
         conf.low = exp(conf.low),
         conf.high = exp(conf.high))

## ---- eval=FALSE--------------------------------------------------------------
#  mtcars = mtcars %>%
#    mutate(`Miles Per Gallon` = mpg)

## ---- echo=FALSE, eval=TRUE---------------------------------------------------
cat('```{r, fig.cap="Relationship between fuel efficiency and the horsepower of a vehicle."}',"\n",
"qplot(data = mtcars","\n",
"      x = hp", "\n",
"      y = mpg) +", "\n",
'  labs(x = "Horse Power",', "\n",
'       y = "Miles per Gallon")', "\n",
"```","\n", sep="")

## ---- echo=FALSE, eval=TRUE, fig.cap="Relationship between fuel efficiency and the horsepower of a vehicle."----
qplot(data = mtcars,
      x = hp,
      y = mpg) +
  labs(x = "Horse Power",
       y = "Miles per Gallon")

## ---- echo=TRUE, eval=FALSE---------------------------------------------------
#  mtcars = mtcars %>%
#    mutate(cyl = factor(cyl))

## ---- echo=TRUE, eval=FALSE---------------------------------------------------
#  mtcars = mtcars %>%
#    mutate(cyl = recode(cyl,
#                        `4` = "4 Cylinder",
#                        `6` = "6 Cylinder",
#                        `8` = "8 Cylinder"))

