## ----setup, include=FALSE------------------------------------------------
## ---- Load Packages ----
pkgs <- c("tidyverse",
          "broom",
          "knitr",
          "IntroAnalysis")

for(pkg in pkgs) library(pkg, character.only = TRUE)


## ---- Change Options ----
# Suppress status bar in dplyr.
# Change handling of ordered factors
options(dplyr.show_progress = FALSE,
        contrasts = rep("contr.treatment", 2))

# Change theme for plots
theme_set(theme_bw(12))
theme_update(legend.position = "bottom")

## ----data, echo=FALSE----------------------------------------------------
mtcars <- datasets::mtcars

mtcars %>%
  head() %>%
  knitr::kable(digits = 3)

## ----packages, eval=FALSE, echo=TRUE-------------------------------------
#  ## ---- Load Packages ----
#  pkgs <- c("tidyverse",
#            "knitr",
#            "IntroAnalysis")
#  
#  for(pkg in pkgs) library(pkg, character.only = TRUE)
#  
#  
#  ## ---- Change Options ----
#  # Suppress status bar in dplyr.
#  # Change handling of ordered factors
#  options(dplyr.show_progress = FALSE,
#          contrasts = rep("contr.treatment", 2))
#  
#  # Change theme for plots
#  theme_set(theme_bw(12))
#  theme_update(legend.position = "bottom")

## ---- echo=FALSE, eval=TRUE----------------------------------------------
cat("```{r}","\n", "Code goes here...","\n", "```", "\n", sep="")

## ---- echo=TRUE, eval=FALSE----------------------------------------------
#  # Comments (not evaluated) begin with a hashtag.
#  ObjectName = code to generate results

## ---- echo=TRUE, eval=FALSE----------------------------------------------
#  ObjectTwo = ObjectOne %>%
#    summarise()

## ----mutate--------------------------------------------------------------
mtcars = mtcars %>%
  mutate(Gallons_per_Mile = 1/mpg)

## ---- echo=FALSE---------------------------------------------------------
mtcars %>%
  head() %>%
  knitr::kable(digits = 3)

## ----filter--------------------------------------------------------------
automatic.only = mtcars %>%
  filter(am == 0)

## ---- echo=FALSE---------------------------------------------------------
automatic.only %>%
  head() %>%
  knitr::kable(digits = 3)

## ----factors-------------------------------------------------------------
mtcars = mtcars %>%
  mutate(am = recode(am, 
                     `0` = "automatic",
                     `1` = "manual"))

## ---- echo=FALSE---------------------------------------------------------
mtcars %>%
  head() %>%
  knitr::kable(digits = 3)

## ----factors-cont--------------------------------------------------------
mtcars = mtcars %>%
  mutate(am = recode(am, 
                     "automatic" = "Automatic Transmission",
                     "manual" = "Manual Transmission"))

## ----summarise_one-------------------------------------------------------
summarize_variable(mpg ~ 1, data = mtcars, mean, sd)

## ----summarise_two-------------------------------------------------------
summarize_variable(mpg ~ am, data = mtcars, mean, sd)

## ----summarise-----------------------------------------------------------
summarize_variable((am=="Manual Transmission") ~ 1, data = mtcars, percent)

## ----summary_missing-----------------------------------------------------
summarize_variable(mpg ~ 1, data = mtcars, mean, .args = list(na.rm = TRUE))

## ----summary_relationship------------------------------------------------
summarize_relationship(mpg ~ hp, data = mtcars)

## ----bar-chart-----------------------------------------------------------
qplot(data = mtcars,
      x = am,
      geom = "bar") +
  labs(x = "",
       y = "Frequency")

## ------------------------------------------------------------------------
mtcars = mtcars %>%
  mutate(vs = recode(vs,
                     `0` = "V Engine",
                     `1` = "Straight Engine"))

## ----double-bar-chart----------------------------------------------------
qplot(data = mtcars,
      x = am,
      fill = vs,
      geom = "bar") +
  labs(x = "",
       fill = "",
       y = "Frequency")

## ----histogram-1---------------------------------------------------------
qplot(data = mtcars,
      x = mpg,
      geom = "histogram",
      binwidth = 1) +
  labs(x = "Miles per Gallon",
       y = "Frequency")

## ----histogram-2---------------------------------------------------------
qplot(data = mtcars,
      x = mpg,
      geom = "histogram",
      binwidth = 3) +
  labs(x = "Miles per Gallon",
       y = "Frequency")

## ----histogram-3---------------------------------------------------------
qplot(data = mtcars,
      x = mpg,
      geom = "histogram") +
  labs(x = "Miles per Gallon",
       y = "Frequency")

## ----density-plot--------------------------------------------------------
qplot(data = mtcars,
      x = mpg,
      geom = "density") +
  labs(x = "Miles per Gallon",
       y = "Density")

## ----box-plot------------------------------------------------------------
qplot(data = mtcars,
      y = mpg,
      x = "",
      geom = "boxplot") +
  labs(y = "Miles per Gallon",
       x = "")

## ----boxplot-1-----------------------------------------------------------
qplot(data = mtcars,
      y = mpg,
      x = am,
      geom = "boxplot") +
  labs(x = "",
       y = "Miles per Gallon")

## ----violin-plots--------------------------------------------------------
qplot(data = mtcars,
      y = mpg,
      x = am,
      geom = "violin") +
  labs(x = "",
       y = "Miles per Gallon")

## ----ivp-----------------------------------------------------------------
qplot(data = mtcars,
      y = mpg,
      x = am,
      geom = "point") +
  labs(x = "",
       y = "Miles per Gallon")

## ----jitter--------------------------------------------------------------
qplot(data = mtcars,
      y = mpg,
      x = am,
      geom = "jitter",
      height = 0) +
  labs(x = "",
       y = "Miles per Gallon")

## ----boxplot-2-----------------------------------------------------------
qplot(data = mtcars,
      y = mpg,
      x = am,
      fill = vs,
      geom = "boxplot") +
  labs(x = "",
       y = "Miles per Gallon",
       fill = "")

## ----scatterplot-1-------------------------------------------------------
qplot(data = mtcars,
      y = mpg,
      x = wt,
      geom = "point") +
  labs(y = "Miles per Gallon",
       x = "Weight (1000 lbs)")

## ----scatterplot-2-------------------------------------------------------
qplot(data = mtcars,
      y = mpg,
      x = wt,
      color = am,
      geom = "point") +
  labs(y = "Miles per Gallon",
       x = "Weight (1000 lbs)",
       color = "")

## ----scatterplot-3-------------------------------------------------------
qplot(data = mtcars,
      y = mpg,
      x = wt,
      shape = am,
      geom = "point") +
  labs(y = "Miles per Gallon",
       x = "Weight (1000 lbs)",
       shape = "")

## ----scatterplot-4-------------------------------------------------------
qplot(data = mtcars,
      y = mpg,
      x = wt,
      color = hp,
      geom = "point") +
  labs(y = "Miles per Gallon",
       x = "Weight (1000 lbs)",
       color = "Horsepower")

## ----scatterplot-5-------------------------------------------------------
qplot(data = mtcars,
      y = mpg,
      x = wt,
      size = hp,
      geom = "point") +
  labs(y = "Miles per Gallon",
       x = "Weight (1000 lbs)",
       size = "Horsepower")

## ----specify-model-------------------------------------------------------
mpg.model = specify_mean_model(mpg ~ 1, data = mtcars)

## ----ref.label="specify-model"-------------------------------------------
mpg.model = specify_mean_model(mpg ~ 1, data = mtcars)

## ------------------------------------------------------------------------
estimate_parameters(mpg.model,
                    confidence.level = 0.95,
                    assume.identically.distributed = TRUE,
                    assume.normality = TRUE)

## ----single-boot---------------------------------------------------------
estimate_parameters(mpg.model,
                    confidence.level = 0.95,
                    assume.identically.distributed = TRUE,
                    assume.normality = FALSE)

## ------------------------------------------------------------------------
set.seed(123)
estimate_parameters(mpg.model,
                    confidence.level = 0.95,
                    assume.identically.distributed = TRUE,
                    assume.normality = FALSE)

## ------------------------------------------------------------------------
sampling.distn = estimate_parameters(mpg.model,
                                     confidence.level = 0.95,
                                     assume.identically.distributed = TRUE,
                                     assume.normality = FALSE)

plot_sampling_distribution(sampling.distn,
                           show.confidence.interval = TRUE)

## ------------------------------------------------------------------------
sampling.distn

## ----mean-h1-------------------------------------------------------------
mpg.model.h1 = specify_mean_model(mpg ~ 1, data = mtcars)

## ----mean-h0-------------------------------------------------------------
mpg.model.h0 = specify_mean_model(mpg ~ constant(18), data = mtcars)

## ----mean-compare--------------------------------------------------------
compare_models(mpg.model.h1,
               mpg.model.h0,
               assume.identically.distributed = TRUE,
               assume.normality = TRUE)

## ------------------------------------------------------------------------
null.distn = compare_models(mpg.model.h1,
               mpg.model.h0,
               assume.identically.distributed = TRUE,
               assume.normality = FALSE)

plot_null_distribution(null.distn,
                       show.pvalue = TRUE)

## ------------------------------------------------------------------------
null.distn

## ----reg-----------------------------------------------------------------
reg.model = specify_mean_model(mpg ~ 1 + wt, data = mtcars)

## ----ls-estimates--------------------------------------------------------
estimate_parameters(reg.model)

## ------------------------------------------------------------------------
estimate_parameters(reg.model, 
                    confidence.level = 0.99,
                    assume.identically.distributed = TRUE,
                    assume.normality = TRUE)

## ----reg-comparison------------------------------------------------------
reg.model.h1 = specify_mean_model(mpg ~ 1 + hp, data = mtcars)
reg.model.h0 = specify_mean_model(mpg ~ 1, data = mtcars)

## ----compare-regressions-------------------------------------------------
compare_models(reg.model.h1,
               reg.model.h0,
               assume.identically.distributed = TRUE,
               assume.normality = TRUE)

## ----r2------------------------------------------------------------------
glance(reg.model)

## ----reg-augment---------------------------------------------------------
mtcars.augment = obtain_diagnostics(reg.model, data = mtcars)

## ---- echo=FALSE---------------------------------------------------------
mtcars.augment %>%
  head() %>%
  knitr::kable(digits = 3)

## ----reg-time-series-----------------------------------------------------
qplot(data = mtcars.augment,
      y = .resid,
      x = seq_along(.resid),
      geom = c("line", "point")) +
  labs(y = "Residuals",
       x = "Order of Observations")

## ----reg-resid-1---------------------------------------------------------
qplot(data = mtcars.augment,
      y = .resid,
      x = .fitted,
      geom = "point") +
  labs(y = "Residuals",
       x = "Fitted Values")

## ----reg-resid-2---------------------------------------------------------
qplot(data = mtcars.augment,
      y = .resid,
      x = .fitted,
      geom = c("point", "smooth")) +
  labs(y = "Residuals",
       x = "Fitted Values")

## ----reg-prob-plot-------------------------------------------------------
qplot(data = mtcars.augment,
      sample = .resid,
      geom = "qq") +
  labs(x = "Theoretical Quantiles",
       y = "Sample Quantiles")

## ----mean-response-------------------------------------------------------
estimate_mean_response(reg.model,
                       confidence.level = 0.95,
                       assume.identically.distributed = TRUE,
                       assume.normality = TRUE,
                       wt = c(2, 3))

## ----anova-fit-----------------------------------------------------------
anova.model = specify_mean_model(mpg ~ am, data = mtcars)

## ----anova-compare-------------------------------------------------------
anova.model.h1 = specify_mean_model(mpg ~ am, data = mtcars)
anova.model.h0 = specify_mean_model(mpg ~ 1, data = mtcars)

compare_models(anova.model.h1,
               anova.model.h0,
               assume.identically.distributed = TRUE,
               assume.normality = TRUE)

## ----side-by-side-residuals----------------------------------------------
mtcars.augment = obtain_diagnostics(anova.model.h1, data = mtcars)

qplot(data = mtcars.augment,
      y = .resid,
      x = am,
      geom = "boxplot") +
  labs(y = "Residuals",
       x = "")

## ---- eval=FALSE---------------------------------------------------------
#  mtcars = mtcars %>%
#    mutate(`Miles Per Gallon` = mpg)

## ---- echo=FALSE, eval=TRUE----------------------------------------------
cat('```{r, fig.cap="Relationship between fuel efficiency and the horsepower of a vehicle."}',"\n",
"qplot(data = mtcars","\n",
"      x = hp", "\n",
"      y = mpg) +", "\n",
'  labs(x = "Horse Power",', "\n",
'       y = "Miles per Gallon")', "\n",
"```","\n", sep="")

## ---- echo=FALSE, eval=TRUE, fig.cap="Relationship between fuel efficiency and the horsepower of a vehicle."----
qplot(data = mtcars,
      x = hp,
      y = mpg) +
  labs(x = "Horse Power",
       y = "Miles per Gallon")

## ---- echo=TRUE, eval=FALSE----------------------------------------------
#  mtcars = mtcars %>%
#    mutate(cyl = factor(cyl))

## ---- echo=TRUE, eval=FALSE----------------------------------------------
#  mtcars = mtcars %>%
#    mutate(cyl = recode(cyl,
#                        `4` = "4 Cylinder",
#                        `6` = "6 Cylinder",
#                        `8` = "8 Cylinder"))

