## ---- eval=FALSE---------------------------------------------------------
#  install.packages(IntroAnalysis)

## ------------------------------------------------------------------------
library(IntroAnalysis)

## ---- eval=TRUE, echo=FALSE----------------------------------------------
set.seed(20180227)

## ------------------------------------------------------------------------
fit_single <- lm(mpg ~ 1, data = mtcars)

## ------------------------------------------------------------------------
estimate_parameters(fit_single,
                    conf.level = 0.95,
                    assume.normality = TRUE)

## ------------------------------------------------------------------------
t.test(mtcars$mpg, conf.level = 0.95)

## ------------------------------------------------------------------------
estimate_parameters(fit_single,
                    conf.level = 0.95,
                    assume.normality = FALSE)

## ------------------------------------------------------------------------
mtcars$am <- factor(mtcars$am,
                    levels = c(0, 1),
                    labels = c("automatic", "manual"))

## ------------------------------------------------------------------------
fit_two <- lm(mpg ~ am, data = mtcars)

## ------------------------------------------------------------------------
estimate_parameters(fit_two,
                    conf.level = 0.95,
                    assume.constant.variance = TRUE,
                    assume.normality = TRUE)

## ------------------------------------------------------------------------
estimate_parameters(fit_two,
                    conf.level = 0.95,
                    assume.constant.variance = FALSE,
                    assume.normality = FALSE)

## ------------------------------------------------------------------------
fit_two_alt <- lm(mpg ~ am - 1, data = mtcars)
estimate_parameters(fit_two_alt)

## ------------------------------------------------------------------------
fit_reg <- lm(mpg ~ am + hp, data = mtcars)
estimate_parameters(fit_reg)

## ------------------------------------------------------------------------
estimate_parameters(fit_reg,
                    assume.constant.variance = TRUE,
                    assume.normality = FALSE)

## ------------------------------------------------------------------------
mtcars$cyl <- factor(mtcars$cyl,
                     levels = c(4, 6, 8))

## ------------------------------------------------------------------------
fit_anova1 <- lm(mpg ~ cyl, data = mtcars)
fit_anova0 <- lm(mpg ~ 1, data = mtcars)

## ------------------------------------------------------------------------
compare_models(fit_anova1,
               fit_anova0,
               assume.constant.variance = TRUE,
               assume.normality = TRUE)

## ------------------------------------------------------------------------
summary(aov(mpg ~ cyl, data = mtcars))

## ------------------------------------------------------------------------
anova(fit_anova0, fit_anova1)

## ------------------------------------------------------------------------
compare_models(fit_anova1,
               fit_anova0,
               assume.constant.variance = TRUE,
               assume.normality = FALSE)

## ------------------------------------------------------------------------
compare_models(fit_anova1,
               fit_anova0,
               assume.constant.variance = FALSE,
               assume.normality = FALSE)

## ---- eval=FALSE---------------------------------------------------------
#  fit_anova1 <- lm(mpg ~ cyl - 1, data = mtcars)

## ------------------------------------------------------------------------
fit_reg1 <- lm(mpg ~ hp + cyl, data = mtcars)
fit_reg0 <- lm(mpg ~ cyl, data = mtcars)

compare_models(fit_reg1,
               fit_reg0,
               assume.constant.variance = TRUE,
               assume.normality = TRUE)

## ------------------------------------------------------------------------
fit_reg0_alt <- lm(mpg ~ hp, data = mtcars)

compare_models(fit_reg1,
               fit_reg0_alt,
               assume.constant.variance = TRUE,
               assume.normality = TRUE)

## ------------------------------------------------------------------------
compare_models(fit_reg1,
               fit_reg0_alt,
               assume.constant.variance = FALSE,
               assume.normality = FALSE)

## ------------------------------------------------------------------------
fit_single1 <- lm(mpg ~ 1, data = mtcars)

## ------------------------------------------------------------------------
fit_single0 <- lm(mpg ~ -1, offset = rep(23, length(mpg)), data = mtcars)

## ------------------------------------------------------------------------
compare_models(fit_single1,
               fit_single0,
               assume.constant.variance = TRUE,
               assume.normality = TRUE)

## ------------------------------------------------------------------------
compare_models(fit_single1,
               23,
               assume.constant.variance = TRUE,
               assume.normality = TRUE)

## ------------------------------------------------------------------------
fit_single1 <- lm(mpg ~ 1, data = mtcars)

samp_distn <- estimate_parameters(fit_single1)
samp_distn

## ------------------------------------------------------------------------
plot_sampling_distribution(samp_distn)

## ------------------------------------------------------------------------
null_distn <- compare_models(fit_single1, 23)

plot_null_distribution(null_distn)

