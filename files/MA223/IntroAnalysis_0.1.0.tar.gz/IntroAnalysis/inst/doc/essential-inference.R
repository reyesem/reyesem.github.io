## ---- eval=FALSE---------------------------------------------------------
#  install.packages(IntroAnalysis)

## ------------------------------------------------------------------------
library(IntroAnalysis)

## ---- eval=TRUE, echo=FALSE----------------------------------------------
mtcars <- datasets::mtcars
set.seed(20180228)

## ------------------------------------------------------------------------
fit_single <- specify_mean_model(mpg ~ 1, data = mtcars)

## ------------------------------------------------------------------------
estimate_parameters(fit_single,
                    confidence.level = 0.95,
                    assume.identically.distributed = TRUE,
                    assume.normality = TRUE)

## ------------------------------------------------------------------------
t.test(mtcars$mpg, conf.level = 0.95)

## ------------------------------------------------------------------------
estimate_parameters(fit_single,
                    confidence.level = 0.95,
                    assume.identically.distributed = TRUE,
                    assume.normality = FALSE)

## ------------------------------------------------------------------------
mtcars$am <- factor(mtcars$am,
                    levels = c(0, 1),
                    labels = c("automatic", "manual"))

## ------------------------------------------------------------------------
fit_two <- specify_mean_model(mpg ~ 1 + am, data = mtcars)

## ------------------------------------------------------------------------
estimate_parameters(fit_two,
                    confidence.level = 0.95,
                    assume.identically.distributed = TRUE,
                    assume.normality = TRUE)

## ------------------------------------------------------------------------
estimate_parameters(fit_two,
                    confidence.level = 0.95,
                    assume.identically.distributed = FALSE,
                    assume.normality = FALSE)

## ------------------------------------------------------------------------
fit_two_alt <- specify_mean_model(mpg ~ am, data = mtcars)
estimate_parameters(fit_two_alt,
                    confidence.level = 0.95,
                    assume.identically.distributed = TRUE,
                    assume.normality = TRUE)

## ------------------------------------------------------------------------
fit_reg <- lm(mpg ~ 1 + am + hp, data = mtcars)
estimate_parameters(fit_reg,
                    confidence.level = 0.95,
                    assume.identically.distributed = TRUE,
                    assume.normality = TRUE)

## ------------------------------------------------------------------------
estimate_parameters(fit_reg,
                    confidence.level = 0.95,
                    assume.identically.distributed = TRUE,
                    assume.normality = FALSE)

## ------------------------------------------------------------------------
mtcars$cyl <- factor(mtcars$cyl,
                     levels = c(4, 6, 8))

## ------------------------------------------------------------------------
fit_anova1 <- specify_mean_model(mpg ~ cyl, data = mtcars)
fit_anova0 <- specify_mean_model(mpg ~ 1, data = mtcars)

## ------------------------------------------------------------------------
compare_models(fit_anova1,
               fit_anova0,
               assume.identically.distributed = TRUE,
               assume.normality = TRUE)

## ------------------------------------------------------------------------
summary(aov(mpg ~ cyl, data = mtcars))

## ------------------------------------------------------------------------
anova(fit_anova0, fit_anova1)

## ------------------------------------------------------------------------
compare_models(fit_anova1,
               fit_anova0,
               assume.identically.distributed = TRUE,
               assume.normality = FALSE)

## ------------------------------------------------------------------------
compare_models(fit_anova1,
               fit_anova0,
               assume.identically.distributed = FALSE,
               assume.normality = FALSE)

## ---- eval=FALSE---------------------------------------------------------
#  fit_anova1 <- specify_mean_model(mpg ~ 1 + cyl, data = mtcars)

## ------------------------------------------------------------------------
fit_reg1 <- specify_mean_model(mpg ~ 1 + hp + cyl, data = mtcars)
fit_reg0 <- specify_mean_model(mpg ~ 1 + cyl, data = mtcars)

compare_models(fit_reg1,
               fit_reg0,
               assume.identically.distributed = TRUE,
               assume.normality = TRUE)

## ------------------------------------------------------------------------
fit_reg0_alt <- specify_mean_model(mpg ~ 1 + hp, data = mtcars)

compare_models(fit_reg1,
               fit_reg0_alt,
               assume.identically.distributed = TRUE,
               assume.normality = TRUE)

## ------------------------------------------------------------------------
compare_models(fit_reg1,
               fit_reg0_alt,
               assume.identically.distributed = FALSE,
               assume.normality = FALSE)

## ------------------------------------------------------------------------
fit_single1 <- specify_mean_model(mpg ~ 1, data = mtcars)

## ------------------------------------------------------------------------
fit_single0 <- specify_mean_model(mpg ~ constant(23), data = mtcars)

## ---- eval = FALSE-------------------------------------------------------
#  fit_single0 <- lm(mpg ~ -1, offset = rep(23, length(mpg)), data = mtcars)

## ------------------------------------------------------------------------
compare_models(fit_single1,
               fit_single0,
               assume.identically.distributed = TRUE,
               assume.normality = TRUE)

## ------------------------------------------------------------------------
summarize_variable(mpg ~ am, data = mtcars, mean, sd)

## ------------------------------------------------------------------------
summarize_variable(mpg ~ am, data = mtcars, quantile(., probs = c(0.25)))

## ------------------------------------------------------------------------
summarize_relationship(mpg ~ hp, data = mtcars, FUN = cor)

## ------------------------------------------------------------------------
fit_single1 <- specify_mean_model(mpg ~ 1, data = mtcars)

samp_distn <- estimate_parameters(fit_single1,
                                  confidence.level = 0.95,
                                  assume.identically.distributed = TRUE,
                                  assume.normality = TRUE)
samp_distn

## ------------------------------------------------------------------------
plot_sampling_distribution(samp_distn)

## ------------------------------------------------------------------------
fit_single0 <- specify_mean_model(mpg ~ constant(23), data = mtcars)

null_distn <- compare_models(fit_single1,
                             fit_single0,
                             assume.identically.distributed = TRUE,
                             assume.normality = TRUE)

plot_null_distribution(null_distn)

## ------------------------------------------------------------------------
fit_reg <- specify_mean_model(mpg ~ 1 + hp + cyl, data = mtcars)

estimate_parameters(fit_reg, 
                    confidence.level = 0.95,
                    assume.identically.distributed = TRUE,
                    assume.normality = TRUE)

## ------------------------------------------------------------------------
estimate_mean_response(fit_reg,
                       confidence.level = 0.95,
                       assume.identically.distributed = TRUE,
                       assume.normality = TRUE,
                       hp = 123,
                       cyl = factor(c("6"), levels = c("4", "6", "8")))

## ------------------------------------------------------------------------
diagnostics_mtcars <- obtain_diagnostics(fit_reg, data = mtcars)

## ------------------------------------------------------------------------
fit_p <- specify_mean_model((am=="automatic") ~ 1, data = mtcars, 
                            family = binomial)

## ------------------------------------------------------------------------
estimate_mean_response(fit_p,
                       confidence.level = 0.95,
                       Intercept = 1)

## ------------------------------------------------------------------------
estimate_parameters(fit_p,
                    confidence.level = 0.95)

