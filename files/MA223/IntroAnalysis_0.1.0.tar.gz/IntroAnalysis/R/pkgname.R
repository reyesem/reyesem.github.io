#' Functions for aiding in introductory statistics using linear models.
#'
#' Wrappers are provided that allow a single framework for estimate parameters
#' in a linear model as well as comparing nested linear models (hypothesis
#' testing). This allows us to place the entire introductory statistics course
#' under the umbrella of linear models.
#'
#' The two primary functions you will utilize from \pkg{IntroAnalysis} are
#' \code{\link{estimate_parameters}} and \code{\link{compare_models}}. Note that
#' in order to use these functions, you must be familar with the 
#' \code{\link[stats]{lm}} function.
"_PACKAGE"
