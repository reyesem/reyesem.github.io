library(testthat)
library(IntroAnalysis)

test_check("IntroAnalysis")
